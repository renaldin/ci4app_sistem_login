<?= $this->extend('layout/template');?>


<?= $this->section('content'); ?>
<div class="container mt-4">
    <div class="row">
        <div class="col mt-5">
            <div class="alert alert-primary title" role="alert">
                <h5>Home</h5>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>