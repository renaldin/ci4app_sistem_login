<?= $this->extend('layout/template');?>


<?= $this->section('content');?>
<div class="container mt-4">
    <div class="row">
        <div class="col mt-5">
            <div class="alert alert-primary title" role="alert">
                <h5>About</h5>
            </div>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi expedita non eaque similique provident accusantium esse? Eos veritatis, nulla fugiat perferendis nostrum perspiciatis esse laborum, iste dolores harum enim voluptatem.</p>
        </div>
    </div>
</div>
<?= $this->endSection();?>

    